const fileExt = ".png"
let db =[
    {
    name: 'Пласкогубці',
    id: 00001,
    pic: '00001' + fileExt,
    price: '10'
    },
    {
        name: 'Молоток',
        id: 00002,
        pic: '00002' + fileExt,
        price: '10'
        },
        {
            name: 'Викрутка',
            id: 00003,
            pic: '00003' + fileExt,
            price: '10'
            },
            {
                name: 'Пила',
                id: 00004,
                pic: '00004' + fileExt,
                price: '10'
                },
                {
                    name: 'Рулетка',
                    id: 00005,
                    pic: "00005" + fileExt,
                    price: '10'
                  
                    },
                    {
                        name: 'Цвях',
                        id: 00006,
                        pic: "00006" + fileExt,
                        price: '10'
                      
                        },
                        {
                            name: 'Перфератор',
                            id: 00007,
                            pic: "00007" + fileExt,
                            price: '10'
                          
                            },
                            {
                                name: 'Електропила',
                                id: 00008,
                                pic: "00008" + fileExt,
                                price: '10'
                              
                                },
                                {
                                    name: 'Ключ',
                                    id: 00009,
                                    pic: "00009" + fileExt,
                                    price: '10'
                                  
                                    },
                                    {
                                        name: 'Електродриль',
                                        id: 00010,
                                        pic: "00010" + fileExt,
                                        price: '10'
                                    },
                                    {
                                        name: 'Електролобзік',
                                        id: 00011,
                                        pic: "00011" + fileExt,
                                        price: '10'
                                      
                                        },
                                        {
                                            name: 'Сокира',
                                            id: 00012,
                                            pic: "00012" + fileExt,
                                            price: '10'
                                          
                                            }
                                      
                        
                                    
                                   
                               
                           
                   

                        


];

for(let el of db){
    console.log(el)
    $('.product').append(`<div id= 'code${el.id}' class="productItem"   style="background-image: url(img/${el.pic})">  <div>${el.name}</div>   <div>${el.id}</div></div>`)

}
let goodsArr = [];
let counter = 0;

$('.productItem').click(function(e){
    let targetEl = (e.target.id).substr(4);
    console.log(targetEl)


for(let el of db){
    if(targetEl == el.id){
        goodsArr.push(el.name)
  

    }


};
console.log(goodsArr)
btn.innerText = goodsArr.length;
});
$('.check').hide(0);
bt.onclick = ()=>{
   
    $('#check').show(100)
   
    for(let el of goodsArr ){
        $('#check').append(`   <span> ${el} </span> `)

    
    }
   



}

// $('.check').click(function(){
//   $('.check').hide(100)
// })

var form = document.getElementById("check");

async function handleSubmit(event) {
  event.preventDefault();
  var status =  el.name;
  var data = new FormData(event.target);
  fetch(event.target.action, {
    method: form.method,
    body: data,
    headers: {
      Accept: "application/json",
    },
  })
    .then((response) => {
      if (response.ok) {
        status.innerHTML = "Thanks for your submission!";
        form.reset();
      } else {
        response.json().then((data) => {
          if (Object.hasOwn(data, "errors")) {
            status.innerHTML = data["errors"]
              .map((error) => error["message"])
              .join(", ");
          } else {
            status.innerHTML =
              "Oops! There was a problem submitting your form";
          }
        });
      }
    })
    .catch((error) => {
      status.innerHTML = "Oops! There was a problem submitting your form";
    });
}
form.addEventListener("send", handleSubmit);

document.body.onkeydown = function (e) {
  if (e.keyCode == 13) {
    message.value = "test";
  }
};



